import pygame
import random
#Notes: every class has attributes and methods. every class has def. every method has def. classes has the __init__ method where you set attributes. 




        

class Gamestate:
    def __init__(self)->None:
        pygame.init()
        self.left_pressed = False
        self.right_pressed = False
        self.up_pressed = False
        self.down_pressed = False
        self.clock = pygame.time.Clock()
        self.fps = 30
        self.screen_width = 600
        self.screen_height = 700
        self.numwalls = 50
        self.sprites = pygame.sprite.Group()
        self.gridwidth = int(self.screen_width/self.numwalls)
        self.gridheight = int(self.screen_height/self.numwalls)
        self.board = Board(self)
        self.snake = Snake(self)
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        self.apples = pygame.sprite.Group()
        self.apples.add(Apple(self),Apple(self),Apple(self),Apple(self),Apple(self))
        pygame.display.set_caption("game")
    def play(self)->None:
        self.running = True
        self.moving = False
        while self.running:
            self.clock.tick(self.fps)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
            for bodypart in self.snake.body:
                if bodypart.colliderect(self.snake.head) and self.moving:
                    self.running = False
            pressed = pygame.key.get_pressed()
            if pressed[pygame.K_LEFT]:
                self.snake.x_speed = - self.gridwidth
                self.snake.y_speed = 0
                self.moving = True
            if pressed[pygame.K_RIGHT]:
                self.snake.x_speed = + self.gridwidth
                self.snake.y_speed = 0
                self.moving = True
            if pressed[pygame.K_UP]:
                self.snake.y_speed = - self.gridheight
                self.snake.x_speed = 0
                self.moving = True
            if pressed[pygame.K_DOWN]:
                self.snake.y_speed = + self.gridheight
                self.snake.x_speed = 0
                self.moving = True
            if len(self.snake.bodycoords) > 0:
                self.snake.bodycoords.pop(-1)
                self.snake.bodycoords = [(self.snake.x,self.snake.y)] + self.snake.bodycoords

            


 


            
            self.board.check_collision()
            self.apples.update()
            self.snake.update()
            self.screen.fill("black")
            self.board.draw()
            self.snake.draw()
            self.apples.draw(self.screen)
            pygame.display.update()


class Board:
    def __init__(self, game:Gamestate):
        self.topwall = [(x,0) for x in range(0,game.screen_width,game.gridwidth)]
        self.bottomwall = [(x,game.gridheight*(game.numwalls-1)) for x in range (0,game.screen_width,game.gridwidth)]
        self.leftwall = [(0,y) for y in range (0,game.screen_height, game.gridheight)]
        self.rightwall = [(game.gridwidth*(game.numwalls-1),y) for y in range (0,game.screen_height, game.gridheight)]
        self.walls = self.rightwall + self.leftwall + self.bottomwall + self.topwall
        self.game = game
        self.color = "grey"
        self.wallrects = []
        for coordinate in self.walls:
            self.wallrects.append(pygame.Rect(coordinate[0],coordinate[1], game.gridwidth,game.gridheight))

    def draw(self): 
        for wallrect in self.wallrects:
            pygame.draw.rect(self.game.screen, self.color, wallrect)
    def check_collision(self):
        for wallpiece in self.wallrects:
            collide = wallpiece.colliderect(self.game.snake.head)
            if collide:
                self.game.running = False
        

            
class Snake:
    def __init__(self, game:Gamestate):
        self.length = 2
        self.x = game.screen_width//2
        self.y = game.screen_height//2
        self.head = pygame.Rect(self.x, self.y, game.gridwidth, game.gridheight)
        self.bodycoords = [(self.x, self.y+game.gridheight),(self.x, self.y+(2*game.gridheight))]
        self.game = game
        self.color = "green"
        self.x_speed = 0
        self.y_speed = 0
        self.body = [pygame.Rect(self.x, self.y+game.gridheight, game.gridwidth, game.gridheight),
                     pygame.Rect(self.x, self.y+(2*game.gridheight), game.gridwidth, game.gridheight)]
    
    
    def grow(self):
        self.body.append(pygame.Rect(self.ghost[0],self.ghost[1],game.gridwidth,game.gridheight))
        self.bodycoords.append((self.ghost[0],self.ghost[1]))
        
    def draw(self):
        pygame.draw.rect(self.game.screen, self.color, self.head)
        for bodypart,coordpair in zip(self.body,self.bodycoords):
            bodypart.x = coordpair[0]
            bodypart.y = coordpair[1]
            pygame.draw.rect(self.game.screen, self.color, bodypart)
    def update(self):
        self.ghost = (self.body[-1].x, self.body[-1].y)
        self.x = self.x + self.x_speed
        self.y = self.y + self.y_speed
        self.head.x = self.x
        self.head.y = self.y
        

class Apple(pygame.sprite.Sprite):
    def __init__(self, game:Gamestate):
        super().__init__()
        self.game = game
        self.color = "red"
        self.image = pygame.Surface((game.gridwidth,game.gridheight))
        self.image.fill(self.color)
        self.rect = self.image.get_rect()
        self.x = random.choice(list(range(0 + game.gridwidth, game.screen_width - game.gridwidth, game.gridwidth)))
        self.y = random.choice(list(range(0 + game.gridheight, game.screen_height - game.gridheight, game.gridheight)))
        self.rect.x = self.x
        self.rect.y = self.y
        print(self.x,self.y)
        
    def update(self):
        collided = self.rect.colliderect(self.game.snake.head)
        if collided:
            self.game.apples.remove(self)
            self.game.snake.grow()
            self.game.apples.add(Apple(self.game))
            del self
            




        
        

    



# duplication issue for the length of the snake.




game = Gamestate()
game.play()










# sage = Person("brown", 8)
# print (sage.hair_color)
# print (sage.height)
# sage.say_hi()

# Even = Person("brown", 2)
# print (Even.hair_color)
# print (Even.height)











